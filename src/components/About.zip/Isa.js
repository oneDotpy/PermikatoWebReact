import React, { useState, useEffect, useRef } from 'react';
import './Isa.css';

import utsg from "../assets/png/isa/utsg.jpg"
import utsc from "../assets/png/isa/utsc.jpg"
import utm from "../assets/png/isa/utm.jpg"
import humber from "../assets/png/isa/humber.png"
import tmu from "../assets/png/isa/tmu.jpg"
import uw from "../assets/png/isa/uw.jpg"

import utisa from "../assets/png/isa/utisa.png"
import idnsa from "../assets/png/isa/idnsa.png"
import isautm from "../assets/png/isa/isautm.png"
import isahumber from "../assets/png/isa/isahumber.png"
import tmuisa from "../assets/png/isa/tmuisa.png"
import uwisa from "../assets/png/isa/uwisa.png"

import black from "../assets/png/black.png";

function Isa() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const sliderRef = useRef(null);

  const slides = [
    {
      image: black,
      title: "Indonesisan Student Association around the GTA",
      members: ["Swipe →"],
    },
    {
      image: utsg,
      title: "UTISA",
      members: [
        "Gabriel Reyes Situmeang - President",
        "Dimas Anindito Widjanarko - Vice President",
        "Ariella Maharani Phalosa Panjomuran Siahaan - Secretary",
      ],
    },
    {
      image: utsc,
      title: "IDNSA UTSC",
      members: [
        "Timothy Marcello Pasaribu - Head of RSO",
        "Kayna Mufidah - RSO Associate",
        "Marnala Agnes Aurelia Sinurat - RSO Associate",
      ],
    },
    {
      image: utm,
      title: "UTM ISA",
      members: [
        "Muhammad Nabil Ar-Rafi - Head of ESD",
        "Oswald Jonathan Geraldo - ESD Associate",
        "Aneira Rachmadsyah - ESD Associate",
        "Sekar Ayu Apriliani Wibawa - ESD Associate",
      ],
    },
    {
      image: humber,
      title: "ISA HUMBER",
      members: [
        "Adriana Meriam Elsabel Simanjuntak - Head of EA",
        "Muhammad Enrizky Brillian - Head of EA",
        "Kartika Cahya Kumala - EA Associate",
      ],
    },
    {
      image: tmu,
      title: "TMU ISA",
      members: [
        "Samuel Jediah Gultom - Head of ITMP",
        "Ahnaf Keenan Ardhito - IT Associate",
        "Alexa Chandra - Media Associate",
        "Daniella Talita Putri - Media Associate",
        "Nada Ramadhania - Media Associate",
        "Rafiif Nur Tahta Bagaskara - Media Associate",
      ],
    },
    {
      image: uw,
      title: "UW ISA",
      members: [
        "Gede Deanova Wikayana Fachrie - Head of Stud Eng",
        "Nasywa Atha Talitha - Stud Eng Associate",
        "Roberto Theno Kevin King - Stud Eng Associate",
      ],
    },
  ];

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleTouchStart = (e) => {
    sliderRef.current.touchStartX = e.touches[0].clientX;
  };

  const handleTouchMove = (e) => {
    if (!sliderRef.current.touchStartX) return;
    const touchEndX = e.touches[0].clientX;
    const distance = touchEndX - sliderRef.current.touchStartX;

    if (distance > 50) handlePrev(); // Swipe right
    if (distance < -50) handleNext(); // Swipe left
  };

  useEffect(() => {
    const slider = sliderRef.current;
    slider.style.transform = `translateX(-${currentSlide * 100}vw)`;
    slider.style.transition = "transform 0.5s ease-in-out"; // Smooth transition
  }, [currentSlide]);

  return (
    <section id="team" className="team-section">
      <div className="slider-container" ref={sliderRef}>
        {slides.map((slide, index) => (
          <div
            className="slide"
            key={index}
            style={{
              backgroundImage: `url(${slide.image})`,
            }}
          >
            <div className="overlay">
              <h1>{slide.title}</h1>
              <div className="team-members">
                {slide.members.map((member, i) => (
                  <p key={i}>{member}</p>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Prev and Next arrows */}
      <button className="prev-button" onClick={handlePrev}>←</button>
      <button className="next-button" onClick={handleNext}>→</button>
    </section>
  );
}

export default Isa;